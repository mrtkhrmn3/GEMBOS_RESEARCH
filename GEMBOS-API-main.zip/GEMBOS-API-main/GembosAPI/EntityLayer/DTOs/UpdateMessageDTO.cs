﻿namespace GembosAPI.EntityLayer.DTOs
{
    public class UpdateMessageDTO
    {
        public Guid ID { get; set; }
        public string Body { get; set; }
    }
}
