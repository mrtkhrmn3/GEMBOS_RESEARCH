﻿namespace GembosAPI.EntityLayer.DTOs
{
    public class RegisterDTO
    {
        public string PhoneNumber { get; set; }
        public string Password { get; set; }
        public string verifyPassword{ get; set; }
    }
}
