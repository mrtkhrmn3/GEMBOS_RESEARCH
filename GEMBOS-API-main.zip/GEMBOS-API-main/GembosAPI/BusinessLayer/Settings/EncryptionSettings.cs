﻿namespace GembosAPI.BusinessLayer.Settings
{
    public class EncryptionSettings
    {
        public string Key { get; set; }
        public string IV { get; set; }
    }
}
