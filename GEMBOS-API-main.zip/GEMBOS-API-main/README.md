# GEMBOS
GEMBOS encrypted SMS application
